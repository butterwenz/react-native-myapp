import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';

// 假设您有一个类型定义来描述所有的堆栈参数
type RootStackParamList = {
  Login: undefined;
  Register: undefined;
  // 添加其他屏幕参数类型，如果有的话
};

type LoginScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;

type Props = {
  navigation: LoginScreenNavigationProp;
  setLoginStatus: (status: boolean) => void; // 添加这行来接收从App.tsx传递过来的函数
};

const LoginScreen: React.FC<Props> = ({ navigation, setLoginStatus }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    console.log('Username:', username);
    console.log('Password:', password);
    // 这里你可以添加实际的登录逻辑
    // 假设登录成功
    setLoginStatus(true);
  };

  const handleRegister = () => {
    // 导航到注册画面
    navigation.navigate('Register');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      
      <Button title="登入" onPress={handleLogin} />
      <Text>沒有帳號嗎?</Text>
      <Button title="註冊" onPress={handleRegister} /> 
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
});

export default LoginScreen;
